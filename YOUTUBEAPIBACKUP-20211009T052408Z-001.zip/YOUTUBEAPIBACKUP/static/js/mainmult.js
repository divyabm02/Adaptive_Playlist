// Options
const CLIENT_ID = '22018771299-72uv1qm9n7pcavdhms7iq6f4454i72cr.apps.googleusercontent.com';
const DISCOVERY_DOCS = [
  'https://www.googleapis.com/discovery/v1/apis/youtube/v3/rest'
];
const SCOPES = 'https://www.googleapis.com/auth/youtube.readonly';

const authorizeButton = document.getElementById('authorize-button');
const signoutButton = document.getElementById('signout-button');
const content = document.getElementById('content');
const playlistName = document.getElementById('channel-data');
const videoContainer = document.getElementById('video-container');




// Load auth2 library
function handleClientLoad() {
  gapi.load('client:auth2', initClient);
}

// Init API client library and set up sign in listeners
function initClient() {
  gapi.client
    .init({
      discoveryDocs: DISCOVERY_DOCS,
      clientId: CLIENT_ID,
      scope: SCOPES
    })
    .then(() => {
      // Listen for sign in state changes
      gapi.auth2.getAuthInstance().isSignedIn.listen(updateSigninStatus);
      // Handle initial sign in state
      updateSigninStatus(gapi.auth2.getAuthInstance().isSignedIn.get());
      authorizeButton.onclick = handleAuthClick;
      signoutButton.onclick = handleSignoutClick;
    });
}

// Update UI sign in state changes
function updateSigninStatus(isSignedIn) {
  if (isSignedIn) {
    authorizeButton.style.display = 'none';
    signoutButton.style.display = 'block';
    content.style.display = 'block';
    videoContainer.style.display = 'block';
    requestPlaylist();

} else {
    authorizeButton.style.display = 'block';
    signoutButton.style.display = 'none';
    content.style.display = 'none';
    videoContainer.style.display = 'none';
  }
}

// Handle login
function handleAuthClick() {
  gapi.auth2.getAuthInstance().signIn();
}

// Handle logout
function handleSignoutClick() {
  gapi.auth2.getAuthInstance().signOut();
}

    // Add commas to number
function numberWithCommas(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

// To get playlist ids
function requestPlaylist() {
  const reqOpts = {
    part:["id,snippet"],
    "mine": true
    };

  const req = gapi.client.youtube.playlists.list(reqOpts);

  req.execute(response => {
    console.log(response);
    const playlists = response.result.items;

    if (playlists) {
      // playlists.forEach(item => {
      let output = ``;
      for (const item of playlists){
        const playlistId = item.id;
        const playlistTitle = item.snippet.localized.title;

        output += `<br><h3>Playlist: ${playlistTitle}</h3>`;
        // output += `<br><h3>ID: ${playlistId}</h3>`;

        // txt = requestVideoPlaylist(playlistId) ;
        const requestOptions = {
          playlistId: playlistId,
          part: "snippet",
          maxResults: 50
        };
      
        const request = gapi.client.youtube.playlistItems.list(requestOptions);
        
        request.execute(response => {
          console.log(response);
          const playListItems = response.result.items;
          let output1 = `<br><p>BLAHHHHHHHHHHHHHHHHHHHHH</p>`;
          if (playListItems) {
            output1 += `<br><h4 class="center-align">>Videos</h4>`;
      
            // Loop through videos and append output
            // playListItems.forEach(item => {
            // for (var it of playListItems){

              const videoId = playListItems[0].snippet.resourceId.videoId;
      
              output1 += `  
                <div class="col s3">
                <iframe width="100%" height="auto" src="https://www.youtube.com/embed/${videoId}" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                </div>
              `;
            // };
            // );
      
          // Output videos
          // videoContainer.innerHTML = output;
          } 
          else {
            // videoContainer.innerHTML = 'No videos in the playlist';
            output1 += `<br><h4>No videos</h4>`;
        }

        });

        // output1 += `${txt}`;
      }
      videoContainer.innerHTML = output1;
      // ); 
    }
    else {
      videoContainer.innerHTML = `No Playlists`;
    }

  });   
}

// function requestVideoPlaylist(playlistId) {
//   const requestOptions = {
//     playlistId: playlistId,
//     part: "snippet",
//     maxResults: 50
//   };

//   const request = gapi.client.youtube.playlistItems.list(requestOptions);

//   request.execute(response => {
//     console.log(response);
//     const playListItems = response.result.items;
//     if (playListItems) {
//       let output = `<br><h4 class="center-align">Videos</h4>`;

//       // Loop through videos and append output
//       // playListItems.forEach(item => {
//       //   const videoId = item.snippet.resourceId.videoId;

//       //   output += `  
//       //     <div class="col s3">
//       //     <iframe width="100%" height="auto" src="https://www.youtube.com/embed/${videoId}" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
//       //     </div>
//       //   `;
//       // });

//     // Output videos
//     // videoContainer.innerHTML = output;
//     } 
//     else {
//       // videoContainer.innerHTML = 'No videos in the playlist';
//       let output = `<br><h4>No videos</h4>`;
//   }

//   });
//   return output;
// }

  






  