// Options
const CLIENT_ID = '22018771299-72uv1qm9n7pcavdhms7iq6f4454i72cr.apps.googleusercontent.com';
const DISCOVERY_DOCS = [
  'https://www.googleapis.com/discovery/v1/apis/youtube/v3/rest'
];
const SCOPES = 'https://www.googleapis.com/auth/youtube.readonly';

const authorizeButton = document.getElementById('authorize-button');
const signoutButton = document.getElementById('signout-button');
const content = document.getElementById('content');
// const playlistName = document.getElementById('channel-data');
const videoContainer = document.getElementById('video-container');


// Load auth2 library
function handleClientLoad() {
  gapi.load('client:auth2', initClient);
}

// Init API client library and set up sign in listeners
function initClient() {
  gapi.client
    .init({
      discoveryDocs: DISCOVERY_DOCS,
      clientId: CLIENT_ID,
      scope: SCOPES
    })
    .then(() => {
      // Listen for sign in state changes
      gapi.auth2.getAuthInstance().isSignedIn.listen(updateSigninStatus);
      // Handle initial sign in state
      updateSigninStatus(gapi.auth2.getAuthInstance().isSignedIn.get());
      authorizeButton.onclick = handleAuthClick;
      signoutButton.onclick = handleSignoutClick;
    });
}

// Update UI sign in state changes
function updateSigninStatus(isSignedIn) {
  if (isSignedIn) {
    authorizeButton.style.display = 'none';
    signoutButton.style.display = 'block';
    content.style.display = 'block';
    videoContainer.style.display = 'block';
    requestPlaylist();

} else {
    authorizeButton.style.display = 'block';
    signoutButton.style.display = 'none';
    content.style.display = 'none';
    videoContainer.style.display = 'none';
  }
}

// Handle login
function handleAuthClick() {
  gapi.auth2.getAuthInstance().signIn();
}

// Handle logout
function handleSignoutClick() {
  gapi.auth2.getAuthInstance().signOut();
}


    // Add commas to number
function numberWithCommas(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

// To get playlist ids
function requestPlaylist() {
  const reqOpts = {
    part:['id,snippet'],
    "mine": true
    };

  const req = gapi.client.youtube.playlists.list(reqOpts);

  req.execute(response => {
    console.log(response);
    const playlists = response.result.items;

    if (playlists) {
      // let output1= ``;
      let playlist_IDs = [];
      let playlist_Names = [];
      playlists.forEach(item => {
        let playlistId = item.id;
        // output1 +=`<br>${playlistId}`;
        let playlistTitle = item.snippet.localized.title;
        playlist_IDs.push(playlistId);
        playlist_Names.push(playlistTitle);

      });
      // output1 += `<br><h3?${playlist_IDs}</h3>`;
      // output1 += `<br><h3>${playlist_Names}</h3>`;
      // playlistName.innerHTML = output1;

      requestVideoPlaylist(playlist_IDs, playlist_Names); //???????????????
            
    }

  })
}

function requestVideoPlaylist(playlist_IDs, playlist_Names) {
  var output=`hmm`;
  ID_len = playlist_IDs.length;
  for (i=0; i<ID_len; i++) {
    // output += `<br><h4 class="center-align">Playlist: ${playlist_Names[i]}</h4><br>`;
    // output += `<br><h4 class="center-align">>PlaylistID: ${playlist_IDs[i]}</h4>`;
    let requestOptions = {
      playlistId: playlist_IDs[i],
      part: "snippet",
      maxResults: 50
    };
    var nxtpg = '';
    while(nxtpg){
      if (nxtpg != ''){
        requestOptions.pageToken = nxtpg;
      }
      let request = gapi.client.youtube.playlistItems.list(requestOptions);
  
      request.execute(response => {
        console.log(response);
        nxtpg = response.result.nextPageToken;
        // output += `<br><p>${nxtpg}</p>`;

        const playListItems = response.result.items;
        if (playListItems) {

          // output += '<br><h4 class="center-align">Latest Videos</h4>';
    
          // Loop through videos and append output
          playListItems.forEach(item => {
            let videoId = item.snippet.resourceId.videoId;
    
            output += `
              <div class="col s3">
              <br>
              <iframe width="100%" height="auto" src="https://www.youtube.com/embed/${videoId}" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
              <br><br><br>
              </div>
            `;
          });
    
        // Output videos
        // videoContainer.innerHTML = output;
      } else {
        output += 'No Uploaded Videos';
      }
        videoContainer.innerHTML = output;

    });

  }
}

}





  